package com.cap.bank.dao;

import com.cap.bank.beans.Accountholder1;

public interface IAccountholder1DAO  {
	public boolean createAccount(Accountholder1 bean);

	public double showBalance(Accountholder1 m);
	
	public boolean valid(long id);
	
//	public boolean valid(int pin);
	
	public Accountholder1 displayAccountholder1(long id);
	
	public double deposit(Accountholder1 e,double amount);
	
	public double withDraw(Accountholder1 d,double amount);
	
	public int fundTransfer(Accountholder1 b,Accountholder1 c,double amount);
	
	public Accountholder1 printTransactions(Accountholder1 a);
	
	public Accountholder1 printTrans(long id7);
	

}
