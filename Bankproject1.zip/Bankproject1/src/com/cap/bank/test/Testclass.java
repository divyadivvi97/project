package com.cap.bank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cap.bank.beans.Accountholder1;
import com.cap.bank.services.Accountholder1ServicesImp;

public class Testclass extends Accountholder1ServicesImp {
 
	Accountholder1 a= new Accountholder1();
	Accountholder1 b= new Accountholder1();
	
	Accountholder1ServicesImp c = new Accountholder1ServicesImp();
	@Test
	public void testCreateAccount() {
		assertNotNull(c.createAccount(a));
	}

	

	@Test
	public void testShowBalance() {
		a.setBalance(2000.0);
		assertNotNull(a.getBalance());
		//(a.getBalance(), c.showBalance(a));
	}

	@Test
	public void testDeposit() {
		a.setBalance(3000.0);
		double deposit=a.getBalance();
		assertNotNull(a.getBalance());
		
	}

	@Test
	public void testWithDraw() {
		double withdraw=a.getBalance();
		assertNotNull(a.getBalance());
		
	}

	@Test
	public void testFundTransfer() {
		double amount=a.getBalance();
		assertNotNull(c.fundTransfer(a, b, amount));
	}

	@Test
	public void testPrintTransactions() {
		assertNotNull(c);
	}

}
