package com.capgemini.fake;
public interface IService {
	public Cart updateCart(Integer productId, String emailId);
	public void removeItemFromTheCart(Integer cartId);
}
