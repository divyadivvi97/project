package com.capgemini.fake;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Hello {
	@Autowired
	IService serviceObj;
	@RequestMapping(value="/addToCart")
public ModelAndView cartDetails(@RequestParam("productId") Integer productId)
{
		System.out.println("hello");
		String emailId= "abc@gmail.com"; //session.getAttribute(customeremailId);
		Cart c=serviceObj.updateCart(productId,emailId);
		System.out.println(c);
		
	return new ModelAndView("success","cartDetails",c);
	
}
	@RequestMapping(value="/delete")
	public ModelAndView removeItemFromTheCart(@RequestParam("cartId") Integer cartId)
	{
			/*System.out.println("hello");
			String emailId= "abc@gmail.com"; //session.getAttribute(customeremailId);
*/			serviceObj.removeItemFromTheCart(cartId);
			//System.out.println(c);
			
		return new ModelAndView("delete","message","item removed from the cart");
		
	}
}
