package com.capgemini.fake;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="merchant_product")
public class Product {
	@Id
	@Column(name="product_Id")
	private int productId;
	@Column(name="product_Name")
	private  String productName;
	@Column(name="product_Description")
	private  String productDescription;
	@Column(name="product_Category")
	private String  productCategory;
	@Column(name="product_Price")
	private double productPrice;
	@Column(name="product_Quantity")
	private int productQuantity;
	@Column(name="product_seller_email_Id")
	private String selleremailId;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public String getSelleremailId() {
		return selleremailId;
	}
	public void setSelleremailId(String selleremailId) {
		this.selleremailId = selleremailId;
	}
	public Product() {
		super();
	}
	public Product(int productId, String productName,
			String productDescription, String productCategory,
			double productprice, int productQuantity, String selleremailId) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productDescription = productDescription;
		this.productCategory = productCategory;
		this.productPrice = productprice;
		this.productQuantity = productQuantity;
		this.selleremailId = selleremailId;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName="
				+ productName + ", productDescription=" + productDescription
				+ ", productCategory=" + productCategory + ", productprice="
				+ productPrice + ", productQuantity=" + productQuantity + ", selleremailId="
				+ selleremailId + "]";
	}
	
}
