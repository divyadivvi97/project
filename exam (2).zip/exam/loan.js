function checkme()
{
if(document.frm1.fname.value==""){alert("please fill the firstName");}	

elseif(document.frm1.lname.value==""){alert("please fill the last name");}

elseif(document.frm1.dob.value==""){alert("please fill the dob ");}

else if (document.frm1.gender.value == "") {alert("Please select the gender");}

else if (document.frm1.lang.value == "") {alert("Please select the languages you know");}

else if (document.frm1.getElementById("textarea").value == "") {alert("Please fill the address");}

else if (document.frm1.phno.value == "") {alert("Please enter the phonenumber");}

else if (document.frm1.accno.value == ""){alert("Please enter the accountnumber");}

else if (document.frm1.PAN.value == "") {alert("Please enter the pan number ");}

else if (document.frm1.credit.value == ""){alert("Please enter the credit card number");}

else if (document.frm1.noofyr.value == "") {alert("Please enter no of years");}

else if (document.frm1.roi.value == ""){alert("Please enter rate of interest");}

else if (document.frm1.amt.value == "") {alert("Please enter the loan amount");}

else if (document.frm1.email.value == ""){alert("Please enter the Email Id");}

else
	{
	alert("completed successfully");
	window.location="success.html";
	}




}