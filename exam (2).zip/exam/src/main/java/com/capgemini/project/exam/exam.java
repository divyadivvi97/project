package com.capgemini.project.exam;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.support.PageFactory;

public class exam {
	WebDriver wd;
	public exam(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement username;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement userPwd;
	
	@FindBy(id="female")
	@CacheLookup
	WebElement female;
	
	@FindBy(id="male")
	@CacheLookup
	WebElement male;
	
	@FindBy(id="other")
	@CacheLookup
	WebElement other;
	@FindBy(id="age")
	@CacheLookup
	WebElement age;
	
	@FindBy(id="terms")
	@CacheLookup
	WebElement terms;
	
	@FindBy(className="btn")
	@CacheLookup
	WebElement login;
	
	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public WebElement getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd.sendKeys(userPwd);
	}

	public WebElement getFemale() {
		return female;
	}

	public void setFemale() {
		 female.click();;
	}

	public WebElement getMale() {
		return male;
	}

	public void setMale() {
		 male.click();;
	}

	public WebElement getOther() {
		return other;
	}

	public void setOther() {
	other.click();
	}

	public WebElement getAge() {
		return age;
	}

	public void setAge() {
		age.click();;
	}

	public WebElement getTerms() {
		return terms;
	}

	public void setTerms() {
		terms.click();;
	}

	public WebElement getLogin() {
		return login;
	}

	public void setLogin() {
		login.click();
	}
	
	
	
}
